# Birds Detection > 2023-05-15 7:34pm
https://universe.roboflow.com/subash-shumsher-gautam-fwr7u/birds-detection-jio8n

Provided by a Roboflow user
License: CC BY 4.0

